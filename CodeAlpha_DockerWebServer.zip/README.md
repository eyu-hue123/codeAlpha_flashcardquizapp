# 🐳 CodeAlpha Docker Web Server

This project shows how to containerize a simple web server using **Docker**.

## 📌 Objectives

- Build a containerized web server
- Understand Docker basics
- Practice image building and running

## 🧰 Tools Used

- Docker
- Python (for demo server)

## 🚀 How to Run

```bash
docker build -t web-server .
docker run -p 8080:8080 web-server
```

Then open: http://localhost:8080

## 📂 Folder Structure

```
CodeAlpha_DockerWebServer/
├── web_server.py
├── Dockerfile
└── README.md
```
