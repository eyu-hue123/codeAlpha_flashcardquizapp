# ☕ CodeAlpha Java App using Gradle

This project showcases how to build and manage a Java application using **Gradle**.

## 📌 Objectives

- Automate Java builds with Gradle
- Prepare app for CI/CD pipelines
- Package as JAR

## 🧰 Tools Used

- Java
- Gradle
- GitHub Actions (or Jenkins/Azure DevOps)

## 🚀 How to Build

```bash
./gradlew build
java -jar build/libs/CodeAlpha_JavaGradleApp-1.0-SNAPSHOT.jar
```

## 📂 Folder Structure

```
CodeAlpha_JavaGradleApp/
├── build.gradle
├── src/
│   └── main/java/com/codealpha/App.java
└── README.md
```
