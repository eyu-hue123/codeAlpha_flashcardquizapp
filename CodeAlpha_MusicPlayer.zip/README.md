# 🎧 CodeAlpha Music Player

A simple HTML5 music player built with HTML, CSS, and JavaScript.

## 📌 Features
- Play/Pause/Volume
- Responsive UI

## 🚀 How to Use
Just open `index.html` in your browser.
