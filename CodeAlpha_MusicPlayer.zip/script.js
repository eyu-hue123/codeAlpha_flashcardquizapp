const audio = document.getElementById('audio');
audio.volume = 0.5;