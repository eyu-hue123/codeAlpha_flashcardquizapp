# 🖼️ CodeAlpha Image Gallery

A responsive image gallery using HTML, CSS, and JavaScript.

## 📌 Features
- Responsive layout
- Hover effects
- Lightbox-ready script

## 🚀 Run
Just open `index.html` in your browser.
