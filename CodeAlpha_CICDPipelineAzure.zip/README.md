# 🚀 CodeAlpha CI/CD Pipeline using Azure

This project demonstrates a CI/CD pipeline setup using Azure Pipelines, Container Registry, and App Service.

## 📌 What It Does

- Builds a Docker image from a Python Flask app
- Automates CI/CD pipeline with Azure DevOps
- (Optionally) Pushes image to Azure Container Registry
- Deploys container to Azure App Service

## 🧰 Tools Used

- Azure DevOps
- Azure Container Registry (ACR)
- Azure App Service (Linux, Docker-based)
- Docker
- Python Flask

## 🚀 How to Run

1. Clone this repo
2. Set up an Azure Pipeline using `azure-pipelines.yml`
3. Connect your Azure DevOps project to GitHub
4. (Optional) Configure ACR & App Service deployment

## 📂 Folder Structure

```
CodeAlpha_CICDPipelineAzure/
├── app/
│   ├── app.py
│   └── requirements.txt
├── Dockerfile
├── azure-pipelines.yml
└── README.md
```
