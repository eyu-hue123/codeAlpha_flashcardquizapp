# 🔧 CodeAlpha Jenkins Remoting Project

This project demonstrates the use of **Jenkins Remoting** to connect and manage remote Jenkins agent nodes.

## 📌 Objectives

- Set up Jenkins Master and remote Agent
- Connect agents using SSH or Java Web Start (Remoting)
- Run distributed builds
- Improve CI/CD load balancing

## 🧰 Tools Used

- Jenkins (Master and Agent)
- SSH / Java Remoting
- Ubuntu / Docker
- GitHub

## 🚀 Basic Steps to Implement

1. **Install Jenkins** on your master machine or container.
2. **Create an SSH key** or use Jenkins agent secret.
3. **Launch agent node** from Jenkins dashboard.
4. **Assign labels** to agents and configure your jobs to run there.
5. **Test the build** to ensure the agent is working.

## 📄 Project Files

This folder includes a sample shell script and setup instructions.

## 📂 Folder Structure

```
CodeAlpha_JenkinsRemoting/
├── setup_agent.sh
└── README.md
```

