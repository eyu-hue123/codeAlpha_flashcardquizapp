#!/bin/bash
# Jenkins Remoting Agent Setup Script

echo "Creating Jenkins Agent Workspace..."
mkdir -p ~/jenkins-agent
cd ~/jenkins-agent

echo "Downloading agent.jar from Jenkins Master..."
# Replace this URL with your Jenkins Master host:
wget http://your-jenkins-url.com/jnlpJars/agent.jar

echo "Starting Jenkins Agent..."
# Replace these values with your own:
java -jar agent.jar -jnlpUrl http://your-jenkins-url.com/computer/agent-name/slave-agent.jnlp -secret your-secret-key -workDir "~/jenkins-agent"
